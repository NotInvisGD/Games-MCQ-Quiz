while True:
    print ("")
    print ("This is a MCQ quiz game featuring the following games: Minecraft, Roblox and Geometry Dash!")
    print ("Type 1 for Roblox!\nType 2 for Minecraft!\nTYpe 3 for Geometry Dash!")
    
    try:
       game_name_selected_by_the_user = int(input("Enter your game!: "))
       option_1 = 1
       option_2 = 2
       option_3 = 3
       option_4 = 4
       score = 0
    
       if (game_name_selected_by_the_user == 1):
           game_name_selected_by_the_user_display = "Roblox"
       elif (game_name_selected_by_the_user == 2):
           game_name_selected_by_the_user_display = "Minecraft"
       elif (game_name_selected_by_the_user == 3):
           game_name_selected_by_the_user_display = "Geometry Dash"
    
       if (game_name_selected_by_the_user > 3 or game_name_selected_by_the_user < 1):
           print ("Invalid number!")
           
       else:
           print (f"Cool! The game you have selected is {game_name_selected_by_the_user_display}!")

       def question_roblox_1():
         global score
         print ('''Question 1: Who Invented Roblox?
             
Options:
1. Robert Topala
2. David Baszucki
3. Gabe Newell
4. John Carmack''')
         try:
             answer_number = int(input("Enter your answer number!: "))
             if answer_number == option_2:
                 print ("Correct! David Baszucki built Roblox!")
                 score += 1
             elif answer_number > 4 or answer_number < 1:
                 print ("Please enter a valid answer number!")
                 
             else:
                 print ("Incorrect answer! Option 2 is correct!")
         except ValueError:
             print ("Invalid option! Please select an option between 1 to 4")

       def roblox_question_2():
           global score
           print ("Question 2: In which language is Roblox coded in?")
           print ("")
           print ("Options:")
           print ("1. JavaScript")
           print ("2. C++")
           print ("3. Lua")
           print ("4. Java")

           try:
               answer_number_2 = int(input("Enter your answer number!: "))
               if answer_number_2 == option_3:
                   print ("Correct! Roblox is coded in Lua language!")
                   score += 1
               elif answer_number_2 > 4 or answer_number_2 < 1:
                   print ("Please enter a valid answer number!")
                   
               else:
                   print ("Incorrect answer! Option 3 is correct!")
           except ValueError:
               print ("Invalid option! Please select an option between 1 to 4")
               
    
       def roblox_question_3():
           global score
           print ("Question 3: What year was Roblox officially launched?")
           print ("")
           print ("Options:")
           print ("1. 2006")
           print ("2. 2010")
           print ("3. 2004")
           print ("4. 2005")

           try:
               answer_number_3 = int(input("Enter your answer number!: "))
               if answer_number_3 == option_1:
                   print ("Correct! Roblox was released in 2006!")
                   score += 1
               elif answer_number_3 > 4 or answer_number_3 < 1:
                   print ("Please enter a valid answer number!")
                   
               else:
                   print ("Incorrect answer! Option 1 is correct!")
           except ValueError:
               print ("Invalid option! Please select an option between 1 to 4")
               

       def roblox_question_4():
           global score
           print ("Question 4: What was Roblox originally called during its early development phase?")
           print ("")
           print ("Options:")
           print ("1. Gameblocks")
           print ("2. Robloxia")
           print ("3. Dynablocks")
           print ("4. Build-o-Blocks")

           try:
               answer_number_4 = int(input("Enter your answer number!: "))
               if answer_number_4 == option_3:
                   print ("Correct! Roblox was originally called as Dynablocks!!")
                   score += 1
               elif answer_number_4 > 4 or answer_number_4 < 1:
                   print ("Please enter a valid answer number!: ")
                   
               else:
                   print ("Incorrect answer! Option 1 is correct!")
           except ValueError:
               print ("Invalid option! Please select an option between 1 to 4")
               

       def roblox_question_5():
           global score
           print ("Question 5: Which of the following is NOT a default gear category in Roblox?")
           print ("")
           print ("Options:")
           print ("1. Melee")
           print ("2. Explosive")
           print ("3. Magical")
           print ("4. Vehicles")

           try:
               answer_number_5 = int(input("Enter your answer number!: "))
               if answer_number_5 == option_4:
                  print ("Correct! Vehicles is not a default gear category in Roblox!")
                  score += 1
               elif answer_number_5 > 4 or answer_number_5 < 1:
                   print ("Please enter a valid answer number!")
                  
               else:
                   print ("Incorrect answer! Option 1 is correct!")
           except ValueError:
               print ("Invalid option! Please select an option between 1 to 4")
                
    
       def minecraft_question_1():
           global score
           print ("Question 1: What material do you need to craft a Netherite Ingot?")
           print ("")
           print ("Options:")
           print ("1. Diamond and Gold")
           print ("2. Netherite Scrap and Gold")
           print ("3. Netherite Blocks")
           print ("4. Obsidian and Iron")

           try:
               minecraft_answer_1 = int(input("Enter your answer number!: "))
               if minecraft_answer_1 == option_2:
                   print ("Correct! You need Netherite scrap and Gold for making one netherite ingot!")
                   score += 1
               elif minecraft_answer_1 > 4 or minecraft_answer_1 < 1:
                   print ("Please enter a valid answer number!")
                
               else:
                   print ("Incorrect answer! Option 2 is correct!")
           except ValueError:
               print ("Invalid option! Please select an option between 1 to 4")
               
    
       def minecraft_question_2():
           global score
           print ("Question 2: How many eyes of ender are required to activate an End Portal in a stronghold?")
           score += 1
           print ("")
           print ("Options:")
           print ("1. 12")
           print ("2. 14")
           print ("3. 9")
           print ("4. 10")

           try:
               minecraft_answer_2 = int(input("Enter your answer number!: "))
               if minecraft_answer_2 == option_1:
                  print ("Correct! You need 12 eyes of ender to activate the end portal in a stronghold!")
                  score += 1
               elif minecraft_answer_2 > 4 or minecraft_answer_2 < 1:
                   print ("Please enter a valid answer number!")
                   
               else:
                   print ("Incorrect answer! Option 2 is correct!")
           except ValueError:
               print ("Invalid option! Please select an option between 1 to 4")
               
    
       def minecraft_question_3():
          global score
          print ("Question 3: What is the maximum number of blocks a piston can push?")
          print ("")
          print ("Options:")
          print ("1. 10")
          print ("2. 15")
          print ("3. 12")
          print ("4. Any number of blocks!")

          try:
              minecraft_answer_3 = int(input("Enter your answer number!: "))
              if minecraft_answer_3 == option_3:
                  print ("Correct! You can only push 12 blocks using one piston!")
                  score += 1
              elif minecraft_answer_3 > 4 or minecraft_answer_3 < 1:
                  print ("Please enter a valid answer number!")
                  
              else:
                  print ("Incorrect answer! Option 2 is correct!")
          except ValueError:
              print ("Invalid option! Please select an option between 1 to 4")
              

       def minecraft_question_4():
             global score
             print ("Question 5: Which of these biomes is the rarest to find in Minecraft?")
             print ("")
             print ("Options:")
             print ("1. Jungle")
             print ("2. Badlands")
             print ("3. Mushroom Fields")
             print ("4. Ice Spikes")

             try:
                 minecraft_answer_4 = int(input("Enter your answer number!: "))
                 if minecraft_answer_4 == option_3:
                     print ("Correct! Mushroom fields are the rarest biome to find!")
                     score += 1
                 elif minecraft_answer_4 > 4 or minecraft_answer_4 < 1:
                     print ("Please enter a valid answer number!")
                     
                 else:
                     print ("Incorrect answer! Option 2 is correct!")
             except ValueError:
                 print ("Invalid option! Please select an option between 1 to 4")
                 
    
       def minecraft_question_5():
           global score
           print ("Question 5: What is the precise combination of items needed to create a fully-powered beacon in Survival mode?")
           print ("")
           print ("Options:")
           print ("1. 9 Emerald Blocks")
           print ("2. 156 Blocks of Iron and a Netherite Block")
           print ("3. 132 Blocks of Obsidian")
           print ("4. 164 Blocks of Iron, Gold, Emerald, or Diamond")

           try:
               minecraft_answer_5 = int(input("Enter your answer number!: "))
               if minecraft_answer_5 == option_4:
                   print ("Correct! You seem to be pretty knowlegable, you need 164 Blocks of either Iron, Gold, Emerald or Diamond!")
                   score += 1
               elif minecraft_answer_5 > 4 or minecraft_answer_5 < 1:
                   print ("Please enter a valid answer number!")
                   
               else:
                   print ("Incorrect answer! Option 2 is correct!")
           except ValueError:
               print ("Invalid option! Please select an option between 1 to 4")
               

       def geometryDash_question_1():
           global score
           print ("Who won the best streamer award for geometry dash in 2023?")
           print ("")
           print ("Options:")
           print ("1. Doggie")
           print ("2. Sikky")
           print ("3. GD Colon")
           print ("4. Npesta")

           try:
               gd_answer_1 = int(input("Enter your answer number!: "))
               if gd_answer_1 == option_1:
                   print ("Correct! The 2023 best streamer award was given to Doggie! (when will he verify grief though)")
                   score += 1
               elif gd_answer_1 > 4 or gd_answer_1 < 1:
                   print ("Please enter a valid answer number!")
                   
               else:
                   print ("Incorrect answer! Option 1 is correct!")
           except ValueError:
               print ("Invalid option! Please select an option between 1 to 4")
               
    
       def geometryDash_question_2():
           global score
           print ("Question 2: Who hosted the element series?")
           print ("")
           print ("Options:")
           print ("1. Jax")
           print ("2. Neptune")
           print ("3. FolderRing / DarkX")
           print ("4. GW Arco")

           try:
               gd_answer_2 = int(input("Enter your answer number!: "))
               if gd_answer_2 == option_4:
                   print ("Correct! GW Arco hosted the element series, and the last level in the series is the well- known level ICE CARBON DIABLO X")
                   score += 1
               elif gd_answer_2 > 4 or gd_answer_2 < 1:
                   print ("Please enter a valid answer number!")
                   
               else:
                   print ("Incorrect answer! Option 4 is correct!")
           except ValueError:
               print ("Invalid option! Please select an option between 1 to 4")
               
    
       def geometryDash_question_3():
           global score
           print ("Question 3: Who was the first person to beat bloodbath? (not verify)")
           print ("")
           print ("Options:")
           print ("1. Riot")
           print ("2. Surv")
           print ("3. Viprin")
           print ("4. Quasar")

           try:
               gd_answer_3 = int(input("Enter your answer number!: "))
               if gd_answer_3 == option_4:
                   print ("Correct! Quasar was the first to beat Bloodbath by Riot after Surv had a devastating fail in it!")
                   score += 1
               elif gd_answer_3 > 4 or gd_answer_3 < 1:
                   print ("Please enter a valid answer number!")
                   
               else:
                   print ("Incorrect answer! Option 4 is correct!")
           except ValueError:
               print ("Invalid option! Please select an option between 1 to 4")
               

       def geometryDash_question_4():
           global score
           print ("Question 4: Where can you find the code 'blockbite'?")
           print ("")
           print ("Options:")
           print ("1. In the treasure room")
           print ("2. It's a secret code word in the challenge")
           print ("3. In the help menu")
           print ("4. In the Vault Room")

           try:
               gd_answer_4 = int(input("Enter your answer number!: "))
               if gd_answer_4 == option_3:
                   print ("Correct! You use the code 'blockbite' in the help menu!")
                   score += 1
               elif gd_answer_4 > 4 or gd_answer_4 < 1:
                   print ("Please enter a valid answer number!")
                   
               else:
                   print ("Incorrect answer! Option 3 is correct!")
           except ValueError:
               print ("Invalid option! Please select an option between 1 to 4")
               
    
       def geometryDash_question_5():
           global score
           print ("Question 5: In what update were stars released?")
           print ("")
           print ("Options:")
           print ("1. In 1.3")
           print ("2. In 2.1")
           print ("3. In 1.9")
           print ("4. Always there :)")

           try:
               gd_answer_5 = int(input("Enter your answer number!: "))
               if gd_answer_5 == option_1:
                   print ("Correct! Stars were release in the update 1.3!")
                   score += 1
               elif gd_answer_5 > 4 or gd_answer_5 < 1:
                   print ("Please enter a valid answer number!")
                   
               else:
                   print ("Incorrect answer! Option 1 is correct!")
           except ValueError:
               print ("Invalid option! Please select an option between 1 to 4")
               

       if game_name_selected_by_the_user == 1:
           print ("Printing questions for Roblox!...")
           print ("")
           question_roblox_1()
           print ("")
           roblox_question_2()
           print ("")
           roblox_question_3()
           print ("")
           roblox_question_4()
           print ("")
           roblox_question_5()
           print ("")
           print (f"Your score is {score}")
    
       elif game_name_selected_by_the_user == 2:
           print ("Printing questions for Minecraft!...")
           print ("")
           minecraft_question_1()
           print ("")
           minecraft_question_2()
           print ("")
           minecraft_question_3()
           print ("")
           minecraft_question_4()
           print ("")
           minecraft_question_5()
           print ("")
           print (f"Your score is {score}")

       elif game_name_selected_by_the_user == 3:
           print ("Printing questions for Geometry Dash!...")
           print ("")
           geometryDash_question_1()
           print ("")
           geometryDash_question_2()
           print ("")
           geometryDash_question_3()
           print ("")
           geometryDash_question_4()
           print ("")
           geometryDash_question_5()
           print ("")
           print (f"Your score is {score}")
    
       print ("Thats the game right there! Want to play other games' quiz? Type 1 for yes and 2 for no!")
       yes = 1
       no = 2
       user_continuevity_choice = int(input("Enter your choice!: "))

       if user_continuevity_choice == yes:
           continue
       if user_continuevity_choice == no:
           print ("Thanks for playing the game!")
           break
           
       if user_continuevity_choice != yes and user_continuevity_choice != no:
           print ("Invalid choice, exiting the game!")
           break
    
    except ValueError:
        print ("Please enter a valid number!")